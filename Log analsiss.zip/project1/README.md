# Logs Analysis
================
This project on Logs Analysis has been created as a part of my Full Stack Web Developer Nanodegree Program. 

# Introduction
===============
This project involves creating a python program that will enable to:-
* Query a PostgreSQL database
* View the most popular arcticles of all time from the database
* View the articles that has been accessed the most
* View the most popular articles authors of all time
* Request for dates on which there was more than 1% of requests that lead to errors.

# The Database details
=======================

The PostgreSQL database is provided by the Udacity(newsdata.sql).The database contains three tables named artcles, authors and log.

The description about the articles table can be viewed by executing the following command:-

$ psql news
news=> \d+ articles;

 Column |           Type           |                       Modifiers                       | Storage  | Stats target | Description 
--------+--------------------------+-------------------------------------------------------+----------+--------------+-------------
 author | integer                  | not null                                              | plain    |              | 
 title  | text                     | not null                                              | extended |              | 
 slug   | text                     | not null                                              | extended |              | 
 lead   | text                     |                                                       | extended |              | 
 body   | text                     |                                                       | extended |              | 
 time   | timestamp with time zone | default now()                                         | plain    |              | 
 id     | integer                  | not null default nextval('articles_id_seq'::regclass) | plain    |              | 
Indexes:
    "articles_pkey" PRIMARY KEY, btree (id)
    "articles_slug_key" UNIQUE CONSTRAINT, btree (slug)
Foreign-key constraints:
    "articles_author_fkey" FOREIGN KEY (author) REFERENCES authors(id)
news=> \q

The description about the author table can be viewed by executing the following command:-

$ psql news
news=> \d+ authors;

 Column |  Type   |                      Modifiers                       | Storage  | Stats target | Description 
--------+---------+------------------------------------------------------+----------+--------------+-------------
 name   | text    | not null                                             | extended |              | 
 bio    | text    |                                                      | extended |              | 
 id     | integer | not null default nextval('authors_id_seq'::regclass) | plain    |              | 
Indexes:
    "authors_pkey" PRIMARY KEY, btree (id)
Referenced by:
    TABLE "articles" CONSTRAINT "articles_author_fkey" FOREIGN KEY (author) REFERENCES authors(id)
news=> \q

The description about the log table can be viewed by executing the following command:-

$ psql news
news=> \d+ log;

 Column |           Type           |                    Modifiers                     | Storage  | Stats target | Description 
--------+--------------------------+--------------------------------------------------+----------+--------------+-------------
 path   | text                     |                                                  | extended |              | 
 ip     | inet                     |                                                  | main     |              | 
 method | text                     |                                                  | extended |              | 
 status | text                     |                                                  | extended |              | 
 time   | timestamp with time zone | default now()                                    | plain    |              | 
 id     | integer                  | not null default nextval('log_id_seq'::regclass) | plain    |              | 
Indexes:
    "log_pkey" PRIMARY KEY, btree (id)

news=> \q

# System and Software Requirements
===================================
Operating system: Ubuntu 16.04.5 LTS
Software: python 2.7.12, PostgreSQL 9.5.14

# Environment Setup
====================
The physical machine which I am using is centos 7.2 with Intel(R) Core(TM) i5-4590 CPU @ 3.30GHz with 500GB SCSI Hard Drive,8 GB RAM and 1 NIC card with 1Gbps speed.

For installing a virtual machine, the following configuration were done
a) Install the Oracle VirtualBox (VirtualBox-5.2-5.2.22_126460_el7-1.x86_64) using the below link 
   https://download.virtualbox.org/virtualbox/5.2.22/VirtualBox-5.2-5.2.22_126460_el7-1.x86_64.rpm

   $ wget https://download.virtualbox.org/virtualbox/5.2.22/VirtualBox-5.2-5.2.22_126460_el7-1.x86_64.rpm
   $ sudo yum install VirtualBox-5.2-5.2.22_126460_el7-1.x86_64.rpm -y

b) Download the vagrant software from the https://releases.hashicorp.com/vagrant/2.2.2/vagrant_2.2.2_x86_64.rpm and install it
   $ wget https://releases.hashicorp.com/vagrant/2.2.2/vagrant_2.2.2_x86_64.rpm
   $ sudo yum install vagrant_2.2.2_x86_64.rpm -y

c) Create the Virtual machine after downloading the required file from https://s3.amazonaws.com/video.udacity-data.com/topher/2018/April/5acfbfa3_fsnd-virtual-machine/fsnd-virtual-machine.zip.
   
   $ ls Downloads/fsnd-virtual-machine.zip
   $ cd Downloads
   $ unzip fsnd-virtual-machine.zip
   $ cd FSND-Virtual-Machine
   $ ls 
	CODEOWNERS  README.md  vagrant
   $ cd vagrant
   $ ls
    catalog  forum  tournament  Vagrantfile
   $ vagrant up

d) Start the virtual machine 
   $ vagrant up
   This command will create a Ubuntu 16.04.5 LTS system  with python and postgresql installed as part of the virtual machine creation step fom the Vagrant file and informs that the /vagrant directory inside the virtual machine is synced with the vagrant directory under Downloads/FSND-Virtual-Machine. 

e) Next I have populated the required database file
   The database file has been downloaded from the below link
   https://d17h27t6h515a5.cloudfront.net/topher/2016/August/57b5f748_newsdata/newsdata.zip
   $ wget https://d17h27t6h515a5.cloudfront.net/topher/2016/August/57b5f748_newsdata/newsdata.zip
   $ unzip newdata.zip
   $ ls
    catalog  forum  tournament  Vagrantfile newsdata.zip newsdata.sql
   $ psql -d news -f newsdata.sql 
  
The above psql command will load the data for our use.

# The reporting tool
=====================

This program should give output below:

1. What are the most popular three articles of all time? Which articles have been accessed the most? Present this information as a sorted list with the most popular article at the top.

    Example:
    
    "Princess Shellfish Marries Prince Handsome" — 1201 views
    "Baltimore Ravens Defeat Rhode Island Shoggoths" — 915 views
    "Political Scandal Ends In Political Scandal" — 553 views

2. Who are the most popular article authors of all time? That is, when you sum up all of the articles each author has written, which authors get the most page views? Present this as a sorted list with the most popular author at the top.

    Example:
    
    Ursula La Multa — 2304 views
    Rudolf von Treppenwitz — 1985 views
    Markoff Chaney — 1723 views
    Anonymous Contributor — 1023 views

3. On which days did more than 1% of requests lead to errors? The log table includes a column status that indicates the HTTP status code that the news site sent to the user's browser. (Refer to "HTTP responses" lesson for more information about the idea of HTTP status codes.)

# Run the program(Script)
==========================
 $ python log_analysis.py

 The output is shown in output

#!/usr/bin/python
#Importing DB-API module for PostgreSQL
import psycopg2

#Define the database to use
DBNAME="news"

# Database connection settings
def db_connection(query):
    try:
      db = psycopg2.connect(database=DBNAME)
      c = db.cursor()
      c.execute(query)
      data = c.fetchall()
      db.close()
      return data
    except psycopg2.Error as e:
      print ("Unable to connect to the database")

# Function definition - for most popular three articles of all time
def popular_articles():
    query = """
    SELECT articles.title, count (*) AS num
     FROM articles,log 
      WHERE articles.slug=substr(log.path,10)
       GROUP BY articles.title 
       ORDER BY num DESC 
        LIMIT 3;
    """
    result = db_connection(query)
    print '******** What are the most popular three articles of all time? ********'
    for title, num in result:
	print '"%s" Article is popular with %s numbers.' % (title, num)
    pass

# Function definition - for the most popular article authors of all time
def article_authors():
    query = """
    SELECT authors.name, count(*) AS num
     FROM articles,authors,log
       WHERE log.status='200 OK' AND authors.id=articles.author AND articles.slug=substr(log.path,10)
         GROUP BY authors.name
         ORDER BY num DESC;         
    """
    result = db_connection(query)
    print '******** Who are the most popular article authors of all time? ********'
    for author_name, num in result:
        print '"%s" is popular with %s numbers.' % (author_name, num)
    pass

# Function definition - for the days which lead to more than 1% errors
def error_days():
    query = """
    SELECT total.day,
     ROUND(((errors.error_requests*1.0)/total.requests),3) AS percent
      FROM (SELECT date_trunc('day', time) "day", count(*) AS error_requests 
		FROM log 
                 WHERE status NOT LIKE '200 OK'
                  GROUP BY day) AS errors
            JOIN (SELECT date_trunc('day', time) "day", count(*) AS requests
                    FROM log
                    GROUP BY day) AS total ON total.day=errors.day
	     WHERE (ROUND(((errors.error_requests*1.0)/total.requests),3)>0.01)
              ORDER BY percent DESC
    """
    result = db_connection(query)
    print '******** On which days did more than 1% of requests lead to errors? ********'
    for res_date, http_404 in result:
	error_date = res_date.strftime('%d - %m - %Y')
        errors = str(round(http_404*100)) + '%'
        print '"%s" is date with %s errors.' % (error_date, errors)
    pass
if __name__ == "__main__":
	popular_articles()
        print '\n\n'
        article_authors()
        print '\n\n'
        error_days()
